double mysqrt(const char* val);
